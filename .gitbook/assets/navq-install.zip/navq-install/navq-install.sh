#!/bin/bash
##############################################################################
#   installation script for new NavQ Ubuntu SD card image                    #
#   20210205 - v1.2 	gerald.peklar@nxp.com                                #
##############################################################################

#get current working directory
WORKDIR=$(pwd)

sudo echo "START install script"
sudo echo "thank you for entering su password before ;)"

#### creating basic folder structure

mkdir ~/bin
mkdir ~/src

#### install additional scripts needed

# udev rule for solving vpuenc authorization issue
sudo cp -f $WORKDIR/src/90-gst-vpuenc.rules /etc/udev/rules
sudo udevadm control --reload-rules && udevadm trigger

# install script for video streaming to QGC

#cp -f $WORKDIR/src/qgcvstream ~/bin
#chmod +x ~/bin/qgcvstream

# update packages
echo "### updating packages"
sudo apt update
sudo apt upgrade

# install additional packages generally neede

sudo apt install libglib2.0-dev cmake

# resize-disk to MAX

cp -f $WORKDIR/src/resizeDisk.sh ~/bin
chmod +x ~/bin/resizeDisk.sh
echo "### you need to have enough disk space available for additional software"
echo "### this is your current available space"
df
echo "### Do you like to resize (grow) your diskspace ???"
echo "### Please specify 'eMMC' or 'SDcard' to grow or 'no'" 
read -p "[e/s/no]: " answer
case "$answer" in
	[eE])	sudo ~/bin/resizeDisk.sh eMMC	;;
	[sS])	sudo ~/bin/resizeDisk.sh sd   ;;
	*)	echo "--- NO Disk resize will take place"	;;
esac

echo "### enable a 1Gb swap-file"

sudo fallocate -l 1G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
sudo swapon --show

#### install mavlink-router

echo "### Do you like to install mavlink-router ???"
read -p "[yes/no]: " answer

if [ "yes" == "$answer" ]; then
        echo "..downloading mavlink-router and install"
        mkdir ~/src
        cd ~/src
        git clone https://github.com/intel/mavlink-router.git
        cd mavlink-router
        git submodule update --init --recursive
        ./autogen.sh && ./configure CFLAGS='-g -O2' --sysconfdir=/etc --localstatedir=/var --libdir=/usr/lib --prefix=/usr
	make
	sudo make install
	sudo cp -f $WORKDIR/src/mavlink-router.conf /etc/mavlink-router/main.conf #copy a default config file
	cd ~
	ln -s /etc/mavlink-router/main.conf mavlink-router.conf
	sudo systemctl enable mavlink-router
	sudo systemctl start mavlink-router
fi

#### install ROS2

echo "### Do you like to install ROS2 and rtps ???"
read -p "[yes/no]: " answer

if [ "yes" != "$answer" ]; then
	echo "script terminated - ROS2 is NOT being installed"
        exit 1
fi

## copy start up scripts

sudo cp $WORKDIR/src/start_ROS.sh /usr/local/bin
sudo chmod +x /usr/local/bin/start_ROS.sh
cd ~
ln -s /usr/local/bin/start_ROS.sh

sudo cp $WORKDIR/src/start_ROS.service /etc/systemd/system

## setup ROS2 sources

cd ~
echo "### install dependencies and setting up ROS sources"
sudo rm -rf /usr/lib/libcurl*
sudo apt update
sudo apt install curl gnupg2 lsb-release
curl -s https://raw.githubusercontent.com/ros/rosdistro/master/ros.asc | sudo apt-key add -

# add ROS2 repo to sources
sudo sh -c 'echo "deb [arch=$(dpkg --print-architecture)] http://packages.ros.org/ros2/ubuntu $(lsb_release -cs) main" > /etc/apt/sources.list.d/ros2-latest.list'

## install ROS2 packages

echo "### install ROS2 base package"
sudo apt update
sudo apt install ros-foxy-ros-base

## installing prerequisites for further installation steps

echo "### install dependencies for fastRTPS"
sudo apt install cmake python3-pip gradle python3-colcon-common-extensions gradle
pip3 install --user pyros-genmsg

echo "source /opt/ros/foxy/setup.bash" >> .bashrc

## install FastRTPS-1.8.2

echo "### install FastRTPS"
cd ~/src
git clone --recursive https://github.com/eProsima/Fast-DDS.git -b v2.0.0 FastRTPS-2.0.0
cd FastRTPS-2.0.0
mkdir build
cd build
cmake -DTHIRDPARTY=ON -DSECURITY=ON ..
make
sudo make install

## install Fast-RTPS-Gen

echo "### install Fast-RTPS-Gen"
cd ~/src
git clone --recursive https://github.com/eProsima/Fast-DDS-Gen.git -b v1.0.4 Fast-RTPS-Gen
cd Fast-RTPS-Gen
unset TERM  ## without this gradle will terminate with error on a color terminal
./gradlew assemble
## Added by Landon to attempt to fix unset TERM as root
sudo -s <<EOF
whoami
cd /home/navq/src/Fast-RTPS-Gen
unset TERM
./gradlew install
EOF

echo "### install dependencies for px4_ros_com"
sudo apt install python3-colcon-common-extensions
sudo apt install ros-foxy-eigen3-cmake-module
sudo pip3 install -U setuptools
pip3 install --user pyros-genmsg

## px4_ros_com installation

echo "### install px4_ros_com"
cd ~/
rm -R -f ~/px4_ros_com_ros2/
mkdir -p ~/px4_ros_com_ros2/
git clone https://github.com/rudislabs/px4_ros_com.git ~/px4_ros_com_ros2/px4_ros_com
git clone https://github.com/rudislabs/px4_msgs.git ~/px4_ros_com_ros2/px4_msgs

## build px4_ros_com workspace

## in case of changed configuration e.g. px4_ros_com_ros2/src/px4_ros_com/templates
#cd ~/px4_ros_com_ros2
#rm -rf ./build ./install ./log

echo "### we start now building the px4_ros_com workspace"
echo "### this may take a while... (>30min)"

cd ~/px4_ros_com_ros2/
colcon build --packages-select px4_msgs --symlink-install
colcon build --packages-select px4_ros_com --symlink-install

echo "### Do you like to autostart ROS2 and rtps ???"
read -p "[yes/no]: " answer
if [ "yes" != "$answer" ]; then
	echo "script terminated - ROS2 autostart is NOT being enabled"
    exit 1
fi

## sourcing ROS2 bash files
# In order to run all of your specific ROS2 software successfully,
# you must source the install/setup.bash files in each of your ROS2 workspace folders.

cd ~/
echo "" >> .bashrc
echo "# sourcing ROS2 bash files" >> .bashrc
echo "source ~/px4_ros_com_ros2/install/setup.bash" >> .bashrc

sudo systemctl enable start_ROS.service
sudo systemctl start start_ROS.service
sudo systemctl status start_ROS.service

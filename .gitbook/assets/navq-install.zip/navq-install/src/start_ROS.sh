#!/bin/bash
## startup script for micro_rtps_agent
## agent will communicate to FMUK66 via UDP
## FMUK66 IPv4 addr = 10.0.0.2 
##
## Author: Gerald Peklar <gerald.peklar@nxp.com>  

source /opt/ros/foxy/setup.bash
source ~/px4_ros_com_ros2/install/setup.bash

# Comment out the line that you are not using:

# If you're using T1 Ethernet communication:
micrortps_agent -t UDP -i 10.0.0.2

# If you're using UART communication over the UART3 port:
#micrortps_agent -d /dev/ttymxc2 -b 921600

## add additional ROS nodes to be started below


